## ONOS RIC

Provides a [Helm] chart for deploying µONOS RAN on [Kubernetes].
See the [documentation](https://docs.onosproject.org/onos-ric/docs/deployment/) for more info.
