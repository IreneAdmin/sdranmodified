## Aether ROC API

Provides a [Helm] chart for deploying µONOS Aether ROC API micro service on [Kubernetes].
See the [documentation](https://docs.onosproject.org/onos-docs/docs/content/developers/deploy_with_helm/) for more info.
