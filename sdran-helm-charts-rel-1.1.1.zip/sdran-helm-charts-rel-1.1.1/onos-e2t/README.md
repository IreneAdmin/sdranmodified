## ONOS E2 Termination

Provides a [Helm] chart for deploying µONOS E2 Termination on [Kubernetes].
See the [documentation](https://docs.onosproject.org/onos-ran/docs/deployment/) for more info.
