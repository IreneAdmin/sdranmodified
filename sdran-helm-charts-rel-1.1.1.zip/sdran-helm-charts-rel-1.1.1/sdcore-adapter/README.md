## ONOS SD-Core Adapter

Provides a [Helm] chart for deploying µONOS SD-Core adapter on [Kubernetes].
