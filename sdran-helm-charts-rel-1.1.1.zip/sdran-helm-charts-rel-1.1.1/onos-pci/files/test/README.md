# Helmit Test Files

These files are intended for use by the PCI scale tests. There
is no need to incorporate them into deployment via templates.