## ONOS PCI

Provides a [Helm] chart for deploying µONOS PCI xApp on [Kubernetes].
See the [documentation](https://docs.onosproject.org/onos-ran/docs/deployment/) for more info.
