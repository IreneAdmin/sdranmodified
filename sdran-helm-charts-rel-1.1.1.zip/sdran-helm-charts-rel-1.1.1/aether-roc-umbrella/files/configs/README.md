# Config files

Available in /home/onos at runtime. Needed
to populate onos-topo and onos-config through
a post-install action on startup of µONOS. 

> TODO: automate the process of copying these