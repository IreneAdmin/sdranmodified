## SD-RAN Umbrella chart

Provides a [Helm] chart for deploying ONOS-TOPO, ONOS-GUI, ONOS-RIC,
Handover application, Load Balancing application, and RAN simulator [Kubernetes].
See the [documentation] for more info.

[Kubernetes]: https://kubernetes.io/
[Helm]: https://helm.sh/
[documentation]: https://docs.onosproject.org/developers/deploy_with_helm/
