# Config files

Copied here from ran-simulator/pkg/config

Available in /home/onos at runtime. Needed
to populate onos-topo and onos-config through
a post-install action on startup of sd-ran. 

> TODO: automate the process of copying these