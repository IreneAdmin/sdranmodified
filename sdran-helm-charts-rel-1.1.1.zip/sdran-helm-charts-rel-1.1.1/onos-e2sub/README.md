## ONOS E2 Subscription Manager

Provides a [Helm] chart for deploying µONOS E2 Subscription Manager on [Kubernetes].
See the [documentation](https://docs.onosproject.org/onos-ran/docs/deployment/) for more info.
