## RAN Simulator

Provides a [Helm] chart for deploying µONOS Ran Simulator on [Kubernetes].
See the [documentation](https://docs.onosproject.org/ran-simulator/docs/deployment/) for more info.
