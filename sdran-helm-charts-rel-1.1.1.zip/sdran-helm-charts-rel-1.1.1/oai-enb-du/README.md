## OpenAirInterface eNB DU

Provides a [Helm] chart for deploying OpenAirInterface eNB DU on [Kubernetes].
See the [documentation](https://docs.onosproject.org/onos-ran/docs/deployment/) for more info.
