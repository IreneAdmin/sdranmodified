## OpenAirInterface eNB CU

Provides a [Helm] chart for deploying OpenAirInterface eNB CU on [Kubernetes].
See the [documentation](https://docs.onosproject.org/onos-ran/docs/deployment/) for more info.
