## ONOS RAN Load Balancer

Provides a [Helm] chart for deploying µONOS RAN Load Balancer on [Kubernetes].
See the [documentation](https://docs.onosproject.org/onos-ran/docs/deployment/) for more info.
